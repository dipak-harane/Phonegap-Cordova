cordova-diagnostic-plugin
=========================

The diagnostic plugin allows you to check different device settings in your PhoneGap application

## IMPORTANT
Please note that this repository is a fork of the original, and isn't actively maintained.
